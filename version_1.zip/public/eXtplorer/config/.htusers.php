<?php 
	// ensure this file is being included by a parent file
	if( !defined( '_JEXEC' ) && !defined( '_VALID_MOS' ) ) die( 'Restricted access' );
	$GLOBALS["users"]=array(
	array('admin','$2a$08$c4XDm5Xl1nG9afVPXG1WAuHZpBJv2oX/1elQFFmKh3T6HxKSFunB.','/home/w1ft43q4sr3u/public_html/vadial','http://localhost','1','','7',1),
); 
?>